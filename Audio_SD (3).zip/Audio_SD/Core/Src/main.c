/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : DAC audio by TIM6+DMA (wavetable) + loader CSV desde SD
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "pitches.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef uint32_t u32;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define AUDIO_FS_HZ        20000U
#define WT_SIZE            256U
#define AUDIO_BUF_SAMPLES  512U
#define DAC_MAX_12B        4095U
#define DAC_OFFSET_12B     2048U

/* SD / CSV */
#define MELODY_MAX_NOTES   512
#define LINE_MAX           96
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;
SPI_HandleTypeDef hspi2;
TIM_HandleTypeDef htim6;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
DMA_HandleTypeDef  hdma_dac1;

static uint16_t audio_buf[AUDIO_BUF_SAMPLES];
static uint16_t wavetable[WT_SIZE];
static u32      phase_q16     = 0;
static u32      phase_inc_q16 = 0;
static float    current_freq_hz = 0.0f;
static uint8_t  audio_running   = 0;

static FATFS   g_fs;
static FIL     g_file;
static Note    g_melody_buf[MELODY_MAX_NOTES];
static unsigned g_melody_count = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */
static void MX_DMA_Init(void);

/* Log UART */
static void log_uart(const char* fmt, ...);

/* Audio */
static void WT_InitSine(void);
static inline void Audio_SetFrequency(float freq_hz);
static void FillHalf(u32 offset, u32 len);
static void Audio_Start(void);
static void Audio_Stop(void);
static void PlayNoteHz_Block(float freq_hz, u32 dur_ms);
static void PlayRest_Block(u32 dur_ms);
static void PlayMelody(const Note* mel, u32 count, u32 tempo_ms_per_beat);

/* SD / CSV + utils */
static FRESULT SD_Mount(void);
static FRESULT SD_Unmount(void);
static FRESULT LoadMelodyFromCSV(const char* path,
                                 Note* out_buf, size_t max_notes, unsigned* out_count);
static void    ListDir(const char* path);

/* SPI helpers + raw test */
static uint8_t spi2_txrx(uint8_t b);
static void SD_RawCMD0_Test(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static void log_uart(const char* fmt, ...)
{
  char buf[160];
  va_list ap; va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  if (n < 0) return;
  size_t len = strnlen(buf, sizeof(buf));
  HAL_UART_Transmit(&huart2, (uint8_t*)buf, (uint16_t)len, 200);
}

/******************** Audio ********************/
static void WT_InitSine(void) {
  for (u32 i = 0; i < WT_SIZE; ++i) {
    float s = sinf(2.0f * 3.14159265359f * (float)i / (float)WT_SIZE);
    wavetable[i] = (uint16_t)((s * 0.49f + 0.5f) * (float)DAC_MAX_12B);
  }
}

static inline void Audio_SetFrequency(float freq_hz) {
  current_freq_hz = freq_hz;
  if (freq_hz <= 0.0f) { phase_inc_q16 = 0; return; }
  float step = (freq_hz * (float)WT_SIZE) / (float)AUDIO_FS_HZ;
  phase_inc_q16 = (u32)(step * 65536.0f);
}

static void FillHalf(u32 offset, u32 len) {
  if (phase_inc_q16 == 0) {
    for (u32 i = 0; i < len; ++i) audio_buf[offset + i] = DAC_OFFSET_12B;
    return;
  }
  for (u32 i = 0; i < len; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[offset + i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }
}

static void Audio_Start(void) {
  if (audio_running) return;

  WT_InitSine();
  phase_q16 = 0;

  for (u32 i = 0; i < AUDIO_BUF_SAMPLES; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }

  if (HAL_DAC_Start(&hdac, DAC_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,
                        (u32*)audio_buf, AUDIO_BUF_SAMPLES, DAC_ALIGN_12B_R) != HAL_OK) Error_Handler();
  if (HAL_TIM_Base_Start(&htim6) != HAL_OK) Error_Handler();

  audio_running = 1;
}

static void Audio_Stop(void) {
  if (!audio_running) return;
  HAL_TIM_Base_Stop(&htim6);
  HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
  HAL_DAC_Stop(&hdac, DAC_CHANNEL_1);
  audio_running = 0;
}

static void PlayNoteHz_Block(float freq_hz, u32 dur_ms) {
  Audio_SetFrequency(freq_hz);
  if (!audio_running) Audio_Start();
  HAL_Delay(dur_ms);
}
static void PlayRest_Block(u32 dur_ms) {
  Audio_SetFrequency(0.0f);
  HAL_Delay(dur_ms);
}
static void PlayMelody(const Note* mel, u32 count, u32 tempo_ms_per_beat) {
  for (u32 i = 0; i < count; ++i) {
    float f = mel[i].freq_hz;
    u32 dur = (mel[i].dur_beats * tempo_ms_per_beat) / 4U; /* negra=4 */
    if (f > 0.0f) PlayNoteHz_Block(f, dur);
    else          PlayRest_Block(dur);
    Audio_SetFrequency(0.0f);
    HAL_Delay(dur/8U);
  }
}

/******************** SD / FatFs ********************/
static FRESULT SD_Mount(void)    { return f_mount(&g_fs, "", 1); }
static FRESULT SD_Unmount(void)  { return f_mount(NULL, "", 0); }

static FRESULT LoadMelodyFromCSV(const char* path,
                                 Note* out_buf, size_t max_notes, unsigned* out_count)
{
  *out_count = 0;
  FRESULT fr = f_open(&g_file, path, FA_READ);
  if (fr != FR_OK) return fr;

  char line[LINE_MAX];
  while (f_gets(line, sizeof(line), &g_file)) {
    char* p = line;
    while (*p==' ' || *p=='\t') ++p;
    if (*p=='#' || *p=='\r' || *p=='\n' || *p=='\0') continue;

    char* sep = strchr(p, ',');
    if (!sep) sep = strchr(p, ';');
    if (!sep) continue;

    *sep = '\0';
    const char* s_freq = p;
    const char* s_dur  = sep + 1;

    float    freq = strtof(s_freq, NULL);
    unsigned dur  = (unsigned)strtoul(s_dur, NULL, 10);

    if (*out_count < max_notes) {
      out_buf[*out_count].freq_hz   = freq;             /* 0=REST */
      out_buf[*out_count].dur_beats = (uint8_t)(dur & 0xFF);
      (*out_count)++;
    } else {
      break;
    }
  }

  f_close(&g_file);
  return FR_OK;
}

static void ListDir(const char* path)
{
  DIR dir;
  FILINFO fno;
  FRESULT fr = f_opendir(&dir, path);
  log_uart("dir %s -> %d\r\n", path, fr);
  if (fr != FR_OK) return;

  for (;;) {
    fr = f_readdir(&dir, &fno);
    if (fr != FR_OK || fno.fname[0] == 0) break;
    log_uart(" - %s%s\r\n", fno.fname, (fno.fattrib & AM_DIR) ? "/" : "");
  }
  f_closedir(&dir);
}

/* SPI txrx local */
static uint8_t spi2_txrx(uint8_t b)
{
  uint8_t r = 0xFF;
  HAL_SPI_TransmitReceive(&hspi2, &b, &r, 1, 100);
  return r;
}

/* ===== RAW CMD0 TEST: comprueba CS/MOSI/SCK/SD ===== */
static void SD_RawCMD0_Test(void)
{
  log_uart("RAW CMD0 test...\r\n");

  /* Baja velocidad a /256 para init */
  HAL_SPI_DeInit(&hspi2);
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  if (HAL_SPI_Init(&hspi2) != HAL_OK) Error_Handler();

  /* 80 clocks con CS alto */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);
  HAL_Delay(2);
  for (int i=0; i<10; ++i) spi2_txrx(0xFF);

  /* CMD0 con CS bajo */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);

  uint8_t cmd[6] = {0x40, 0x00,0x00,0x00,0x00, 0x95}; /* CMD0 + CRC válido */
  for (int i=0;i<6;i++) (void)spi2_txrx(cmd[i]);

  /* Lee respuesta hasta 10 bytes (esperado: 0x01) */
  uint8_t resp[10];
  for (int i=0;i<10;i++) {
    resp[i] = spi2_txrx(0xFF);
  }

  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);
  spi2_txrx(0xFF); /* dummy */

  log_uart("RAW CMD0 resp:");
  for (int i=0;i<10;i++) log_uart(" %02X", resp[i]);
  log_uart("\r\n");

  /* Sube velocidad a /16 para operación normal */
  HAL_SPI_DeInit(&hspi2);
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  if (HAL_SPI_Init(&hspi2) != HAL_OK) Error_Handler();
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_SPI2_Init();
  MX_DAC_Init();
  MX_TIM6_Init();
  MX_FATFS_Init();

  /* USER CODE BEGIN 2 */
  MX_DMA_Init();

  /* Fs=20kHz */
  __HAL_TIM_SET_PRESCALER(&htim6, 83);
  __HAL_TIM_SET_AUTORELOAD(&htim6, 49);
  HAL_TIM_GenerateEvent(&htim6, TIM_EVENTSOURCE_UPDATE);

  /* Trigger en DAC CH1 */
  DAC_ChannelConfTypeDef s = {0};
  s.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
  s.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &s, DAC_CHANNEL_1) != HAL_OK) Error_Handler();

  /* Beep de vida */
  Audio_SetFrequency(1000.0f);
  Audio_Start();
  HAL_Delay(200);
  Audio_SetFrequency(0.0f);
  HAL_Delay(120);

  /* ===== Probe rápido ===== */
  log_uart("SPI probe: ");
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);
  HAL_Delay(5);
  for (int i=0;i<10;i++) (void)spi2_txrx(0xFF);
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);
  uint8_t rxb[8];
  for (int i=0;i<8;i++) rxb[i] = spi2_txrx(0xFF);
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);
  for (int i=0;i<8;i++) { char b[8]; int n=snprintf(b,sizeof(b),"%02X ", rxb[i]); HAL_UART_Transmit(&huart2,(uint8_t*)b,(uint16_t)n,100); }
  HAL_UART_Transmit(&huart2,(uint8_t*)"\r\n",2,100);

  /* ===== PRUEBA RAW CMD0 ===== */
  SD_RawCMD0_Test();

  /* ===== Intento normal de FatFs ===== */
  FRESULT fr = SD_Mount();
  log_uart("f_mount=%d\r\n", fr);
  if (fr == FR_OK) {
    ListDir("/");
    ListDir("/MELODIES");

    /* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
       RUTA DEL CSV QUE QUIERES LEER AHORA
       <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */
    const char* candidates[] = {
      "MELODIES/MELODIA.CSV",
      "/MELODIES/MELODIA.CSV",
      "0:/MELODIES/MELODIA.CSV",
      "0:MELODIES/MELODIA.CSV"
    };



    FRESULT fr_open = FR_NO_FILE;
    unsigned loaded = 0;
    for (size_t i = 0; i < sizeof(candidates)/sizeof(candidates[0]); ++i) {
      fr_open = LoadMelodyFromCSV(candidates[i], g_melody_buf, MELODY_MAX_NOTES, &g_melody_count);
      log_uart("open path='%s' -> fr=%d, count=%u\r\n", candidates[i], fr_open, g_melody_count);
      if (fr_open == FR_OK && g_melody_count > 0) { loaded = 1; break; }
    }

    const u32 tempo_ms = 500;
    if (loaded) {
      log_uart("Playing SD melody! notes=%u\r\n", g_melody_count);
      PlayMelody(g_melody_buf, g_melody_count, tempo_ms);
    } else {
      log_uart("No CSV found/parsed; fallback to embedded\r\n");
      PlayMelody(IMPERIAL_MARCH, IMPERIAL_MARCH_LEN, tempo_ms);
    }
    SD_Unmount();
  } else {
    log_uart("Mount failed, fallback\r\n");
    const u32 tempo_ms = 500;
    PlayMelody(IMPERIAL_MARCH, IMPERIAL_MARCH_LEN, tempo_ms);
  }

  Audio_Stop();
  /* USER CODE END 2 */

  while (1) { HAL_Delay(1000); }
}

/* ==== Resto: generado por CubeMX (sin cambios tuyos) ==== */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

static void MX_DAC_Init(void)
{
  DAC_ChannelConfTypeDef sConfig = {0};
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK) { Error_Handler(); }
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM6_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  htim6.Instance = TIM6;
  htim6.Init.Prescaler         = 840-1;
  htim6.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim6.Init.Period            = 9987-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = 16;
  if (HAL_UART_Init(&huart2) != HAL_OK) { Error_Handler(); }
}

static void MX_SPI2_Init(void)
{
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET); /* CS HIGH */

  /* B1 */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /* LD2 */
  GPIO_InitStruct.Pin   = LD2_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* SD CS */
  GPIO_InitStruct.Pin   = SD_CS_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  hdma_dac1.Instance                 = DMA1_Stream5;
  hdma_dac1.Init.Channel             = DMA_CHANNEL_7;
  hdma_dac1.Init.Direction           = DMA_MEMORY_TO_PERIPH;
  hdma_dac1.Init.PeriphInc           = DMA_PINC_DISABLE;
  hdma_dac1.Init.MemInc              = DMA_MINC_ENABLE;
  hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
  hdma_dac1.Init.MemDataAlignment    = DMA_MDATAALIGN_HALFWORD;
  hdma_dac1.Init.Mode                = DMA_CIRCULAR;
  hdma_dac1.Init.Priority            = DMA_PRIORITY_HIGH;
  hdma_dac1.Init.FIFOMode            = DMA_FIFOMODE_DISABLE;
  if (HAL_DMA_Init(&hdma_dac1) != HAL_OK) { Error_Handler(); }

  __HAL_LINKDMA(&hdac, DMA_Handle1, hdma_dac1);

  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
}

void HAL_DAC_ConvHalfCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx; FillHalf(0, AUDIO_BUF_SAMPLES/2);
}
void HAL_DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx; FillHalf(AUDIO_BUF_SAMPLES/2, AUDIO_BUF_SAMPLES/2);
}
/* USER CODE END 4 */

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file; (void)line;
}
#endif
