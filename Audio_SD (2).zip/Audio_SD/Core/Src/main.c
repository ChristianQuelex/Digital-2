/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : DAC audio by TIM6+DMA (wavetable) + hooks para SD
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "pitches.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef uint32_t u32;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define AUDIO_FS_HZ        20000U     /* 20 kHz */
#define WT_SIZE            256U
#define AUDIO_BUF_SAMPLES  512U       /* doble buffer (2x256) */
#define DAC_MAX_12B        4095U
#define DAC_OFFSET_12B     2048U
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;
SPI_HandleTypeDef hspi2;
TIM_HandleTypeDef htim6;
UART_HandleTypeDef huart2;
/* USER CODE BEGIN PV */
/* DMA para DAC1 CH1 */
DMA_HandleTypeDef  hdma_dac1;

/* buffers de audio */
static uint16_t audio_buf[AUDIO_BUF_SAMPLES];
static uint16_t wavetable[WT_SIZE];

/* Fase Q16.16 */
static u32 phase_q16 = 0;
static u32 phase_inc_q16 = 0;

/* estado */
static float   current_freq_hz = 0.0f;
static uint8_t audio_running   = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */
static void MX_DMA_Init(void);

static void WT_InitSine(void);
static inline void Audio_SetFrequency(float freq_hz);
static void FillHalf(u32 offset, u32 len);
static void Audio_Start(void);
static void Audio_Stop(void);

static void PlayNoteHz_Block(float freq_hz, u32 dur_ms);
static void PlayRest_Block(u32 dur_ms);
static void PlayMelody(const Note* mel, u32 count, u32 tempo_ms_per_beat);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static void WT_InitSine(void) {
  for (u32 i = 0; i < WT_SIZE; ++i) {
    float s = sinf(2.0f * 3.14159265359f * (float)i / (float)WT_SIZE);
    wavetable[i] = (uint16_t)((s * 0.49f + 0.5f) * (float)DAC_MAX_12B);
  }
}

static inline void Audio_SetFrequency(float freq_hz) {
  current_freq_hz = freq_hz;
  if (freq_hz <= 0.0f) {
    phase_inc_q16 = 0;
    return;
  }
  float step = (freq_hz * (float)WT_SIZE) / (float)AUDIO_FS_HZ;
  phase_inc_q16 = (u32)(step * 65536.0f);
}

static void FillHalf(u32 offset, u32 len) {
  if (phase_inc_q16 == 0) {
    for (u32 i = 0; i < len; ++i) audio_buf[offset + i] = DAC_OFFSET_12B;
    return;
  }
  for (u32 i = 0; i < len; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[offset + i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }
}

static void Audio_Start(void) {
  if (audio_running) return;

  WT_InitSine();
  phase_q16 = 0;

  /* prellenar buffer */
  for (u32 i = 0; i < AUDIO_BUF_SAMPLES; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }

  /* Arranque: DAC -> DMA -> TIM6 */
  if (HAL_DAC_Start(&hdac, DAC_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,
                        (u32*)audio_buf, AUDIO_BUF_SAMPLES, DAC_ALIGN_12B_R) != HAL_OK) Error_Handler();
  if (HAL_TIM_Base_Start(&htim6) != HAL_OK) Error_Handler();

  audio_running = 1;
}

static void Audio_Stop(void) {
  if (!audio_running) return;
  HAL_TIM_Base_Stop(&htim6);
  HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
  HAL_DAC_Stop(&hdac, DAC_CHANNEL_1);
  audio_running = 0;
}

static void PlayNoteHz_Block(float freq_hz, u32 dur_ms) {
  Audio_SetFrequency(freq_hz);
  if (!audio_running) Audio_Start();
  HAL_Delay(dur_ms);
}
static void PlayRest_Block(u32 dur_ms) {
  Audio_SetFrequency(0.0f);
  HAL_Delay(dur_ms);
}
static void PlayMelody(const Note* mel, u32 count, u32 tempo_ms_per_beat) {
  for (u32 i = 0; i < count; ++i) {
    float    f   = mel[i].freq_hz;
    u32      dur = (mel[i].dur_beats * tempo_ms_per_beat) / 4U; /* negra=4 */
    if (f > 0.0f) PlayNoteHz_Block(f, dur);
    else          PlayRest_Block(dur);
    Audio_SetFrequency(0.0f);
    HAL_Delay(dur/8U);
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_SPI2_Init();
  MX_DAC_Init();
  MX_TIM6_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */
  /* IMPORTANTE: inicializar DMA y NVIC para el DAC */
  MX_DMA_Init();

  /* Forzar TRGO de TIM6 a Fs=20k (por si Cube cambia los valores) */
  __HAL_TIM_SET_PRESCALER(&htim6, 83);   /* 84 MHz / 84 = 1 MHz */
  __HAL_TIM_SET_AUTORELOAD(&htim6, 49);  /* 1 MHz / 50 = 20 kHz */
  //__HAL_TIM_ENABLE_ARPE(&htim6);

  /* Reconfigurar canal DAC con trigger TIM6_TRGO (por si Cube lo dejó en NONE) */
  DAC_ChannelConfTypeDef s = {0};
  s.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
  s.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &s, DAC_CHANNEL_1) != HAL_OK) Error_Handler();

  /* Pequeña prueba: 1 kHz + dos melodías embebidas */
  Audio_SetFrequency(1000.0f);
  Audio_Start();
  HAL_Delay(800);
  Audio_SetFrequency(0.0f);
  HAL_Delay(150);

  const u32 tempo_ms = 500;
  PlayMelody(IMPERIAL_MARCH, IMPERIAL_MARCH_LEN, tempo_ms);
  HAL_Delay(350);
  PlayMelody(HARRY_POTTER, HARRY_POTTER_LEN, tempo_ms);

  Audio_Stop();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    HAL_Delay(1000);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4; /* SYSCLK = 84 MHz */
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2; /* TIM6 clk = 2*PCLK1 = 84 MHz */
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{
  /* USER CODE BEGIN DAC_Init 0 */
  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */
  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK) { Error_Handler(); }

  /** DAC channel OUT1 config (Cube puede sobrescribir; reconfiguramos en USER 2) */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK) { Error_Handler(); }

  /* USER CODE BEGIN DAC_Init 2 */
  /* Nada: la reconfig real (TIM6_TRGO) la hacemos en main() USER CODE 2 */
  /* USER CODE END DAC_Init 2 */
}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{
  /* USER CODE BEGIN TIM6_Init 0 */
  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */
  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 840-1;            /* Cube pondrá algo; ajustamos en USER 2 */
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 9987-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN TIM6_Init 2 */
  /* Ajustamos PSC/ARR exactos en main() (USER CODE 2) */
  /* USER CODE END TIM6_Init 2 */
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  /* USER CODE BEGIN USART2_Init 0 */
  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */
  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN USART2_Init 2 */
  /* USER CODE END USART2_Init 2 */
}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{
  /* USER CODE BEGIN SPI2_Init 0 */
  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */
  /* USER CODE END SPI2_Init 1 */
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;                 /* CS manual */
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16; /* seguro para empezar */
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN SPI2_Init 2 */
  /* USER CODE END SPI2_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level (CS alto idle)*/
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* --- DMA para DAC1 CH1: Stream5/Channel7 --- */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  hdma_dac1.Instance                 = DMA1_Stream5;
  hdma_dac1.Init.Channel             = DMA_CHANNEL_7;
  hdma_dac1.Init.Direction           = DMA_MEMORY_TO_PERIPH;
  hdma_dac1.Init.PeriphInc           = DMA_PINC_DISABLE;
  hdma_dac1.Init.MemInc              = DMA_MINC_ENABLE;
  hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
  hdma_dac1.Init.MemDataAlignment    = DMA_MDATAALIGN_HALFWORD;
  hdma_dac1.Init.Mode                = DMA_CIRCULAR;
  hdma_dac1.Init.Priority            = DMA_PRIORITY_HIGH;
  hdma_dac1.Init.FIFOMode            = DMA_FIFOMODE_DISABLE;
  if (HAL_DMA_Init(&hdma_dac1) != HAL_OK) { Error_Handler(); }

  /* Vincular al DAC1 CH1 */
  __HAL_LINKDMA(&hdac, DMA_Handle1, hdma_dac1);

  /* NVIC */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
}

/* Callbacks de DMA del DAC */
void HAL_DAC_ConvHalfCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx;
  FillHalf(0, AUDIO_BUF_SAMPLES/2);
}
void HAL_DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx;
  FillHalf(AUDIO_BUF_SAMPLES/2, AUDIO_BUF_SAMPLES/2);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) { }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  (void)file; (void)line;
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
