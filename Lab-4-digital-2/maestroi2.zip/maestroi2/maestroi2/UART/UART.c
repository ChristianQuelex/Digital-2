/*
 * UART.c
 *
 * Created: 1/08/2025 11:15:03
 *  Author: Chris Q
 */ 
