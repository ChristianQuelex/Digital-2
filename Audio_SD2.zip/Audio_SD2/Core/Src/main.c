/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : TIM6+DAC+DMA wavetable + CSV desde SD
  *                   Opción A: PA4 en Hi-Z al boot. DAC se inicia solo al disparo.
  *                   SOLO MELODIA2: arranca con flanco H->L en PC2, en bucle.
  *                   Entradas SIN pull interno (usar pull-ups externos).
  ******************************************************************************
  */
/* USER CODE END Header */

/* === HAL / proyecto === */
#include "main.h"
#include "fatfs.h"

/* === C estándar === */
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* === App === */
#include "pitches.h"   /* typedef Note y respaldo embebido opcional */

/* ===== Tipos ===== */
typedef uint32_t u32;

/* ===== Constantes ===== */
#define AUDIO_FS_HZ        20000U
#define WT_SIZE            256U
#define AUDIO_BUF_SAMPLES  512U
#define DAC_MAX_12B        4095U
#define DAC_OFFSET_12B     2048U

/* SD / CSV */
#define MELODY_MAX_NOTES   512
#define LINE_MAX           96

/* Entradas / servicio */
#define POLL_MS            2U
#define DEBOUNCE_MS_LO     15U     /* rebote LOW */
#define DEBOUNCE_MS_HI     30U     /* rebote HIGH (armado) */

/* Reproducción */
#define CSV_TEMPO_MS       500U
#define GAP_DIVISOR        8U

/* ===== Periféricos ===== */
DAC_HandleTypeDef  hdac;
SPI_HandleTypeDef  hspi2;
TIM_HandleTypeDef  htim6;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef  hdma_dac1;

/* ===== Audio ===== */
static uint16_t audio_buf[AUDIO_BUF_SAMPLES];
static uint16_t wavetable[WT_SIZE];
static u32      phase_q16     = 0;
static u32      phase_inc_q16 = 0;
static uint8_t  audio_running = 0;

/* ===== SD ===== */
static FATFS   g_fs;
static FIL     g_file;

/* ===== MELODIA2 en RAM ===== */
static Note     g_melody2[MELODY_MAX_NOTES];
static unsigned g_melody2_count = 0;

/* ===== Player NO BLOQUEANTE ===== */
static const Note* cur_mel   = NULL;
static unsigned    cur_len   = 0;
static uint32_t    cur_tempo = CSV_TEMPO_MS;
static unsigned    cur_idx   = 0;
static uint8_t     cur_stage = 0;          /* 0=nota/rest, 1=gap */
static uint32_t    stage_end_ms = 0;

/* Loop control */
static uint8_t     loop_enabled = 0;       /* 0: no loop, 1: repetir */
static const Note* loop_mel     = NULL;
static unsigned    loop_len     = 0;

/* Trigger control (anti-autostart): requiere HIGH estable y luego LOW estable */
static uint8_t     armed   = 0;            /* 0: esperando HIGH estable; 1: listo para detectar LOW */
static uint8_t     started = 0;            /* 0: aún no arrancó; 1: ya arrancó reproducción en loop */

/* ===== Prototipos ===== */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM6_Init(void);
static void MX_DMA_Init(void);

/* Log */
static void log_uart(const char* fmt, ...);

/* Audio core */
static void WT_InitSine(void);
static inline void Audio_SetFrequency(float freq_hz);
static void FillHalf(u32 offset, u32 len);
static void Audio_Start(void);

/* Player */
static inline uint32_t NoteDurMs(const Note* n, uint32_t tempo_ms);
static void MelodyStart(const Note* mel, unsigned count, uint32_t tempo_ms);
static void MelodyService(void);

/* SD utils */
static FRESULT SD_Mount(void);
static FRESULT SD_Unmount(void);
static FRESULT LoadMelodyFromCSV(const char* path, Note* out_buf, size_t max_notes, unsigned* out_count);
static FRESULT TryOpenList(const char* const* list, size_t n, Note* buf, unsigned* out_cnt);

/* Entradas (debounce) */
static uint8_t DebounceReadLow(GPIO_TypeDef* port, uint16_t pin, uint32_t ms);
static uint8_t DebounceReadHigh(GPIO_TypeDef* port, uint16_t pin, uint32_t ms);

/* ================= Implementación ================= */

static void log_uart(const char* fmt, ...)
{
  char buf[160];
  va_list ap; va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  if (n < 0) return;
  size_t len = strnlen(buf, sizeof(buf));
  HAL_UART_Transmit(&huart2, (uint8_t*)buf, (uint16_t)len, 200);
}

/************ Audio ************/
static void WT_InitSine(void) {
  for (u32 i = 0; i < WT_SIZE; ++i) {
    float s = sinf(2.0f * 3.14159265359f * (float)i / (float)WT_SIZE);
    wavetable[i] = (uint16_t)((s * 0.49f + 0.5f) * (float)DAC_MAX_12B);
  }
}

static inline void Audio_SetFrequency(float freq_hz) {
  if (freq_hz <= 0.0f) { phase_inc_q16 = 0; return; }
  float step = (float)WT_SIZE * freq_hz / (float)AUDIO_FS_HZ;
  phase_inc_q16 = (u32)(step * 65536.0f);
}

static void FillHalf(u32 offset, u32 len) {
  if (phase_inc_q16 == 0) {
    for (u32 i = 0; i < len; ++i) audio_buf[offset + i] = DAC_OFFSET_12B;
    return;
  }
  for (u32 i = 0; i < len; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[offset + i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }
}

static void Audio_Start(void) {
  if (audio_running) return;

  WT_InitSine();
  phase_q16 = 0;

  for (u32 i = 0; i < AUDIO_BUF_SAMPLES; ++i) {
    u32 idx = (phase_q16 >> 16) & (WT_SIZE - 1);
    audio_buf[i] = wavetable[idx];
    phase_q16 += phase_inc_q16;
  }

  if (HAL_DAC_Start(&hdac, DAC_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1,
                        (uint32_t*)audio_buf, AUDIO_BUF_SAMPLES, DAC_ALIGN_12B_R) != HAL_OK) Error_Handler();
  if (HAL_TIM_Base_Start(&htim6) != HAL_OK) Error_Handler();

  audio_running = 1;
}

/************ Player NO BLOQUEANTE ************/
static inline uint32_t NoteDurMs(const Note* n, uint32_t tempo_ms)
{
  uint32_t d = (uint32_t)n->dur_beats * tempo_ms / 4U;
  if (d == 0) d = 1;
  return d;
}

static void MelodyStart(const Note* mel, unsigned count, uint32_t tempo_ms)
{
  if (!mel || count == 0) {
    cur_mel = NULL; cur_len = 0; cur_idx = 0; cur_stage = 0;
    Audio_SetFrequency(0.0f);
    return;
  }
  cur_mel   = mel;
  cur_len   = count;
  cur_tempo = tempo_ms;
  cur_idx   = 0;
  cur_stage = 0;

  uint32_t now = HAL_GetTick();
  Audio_SetFrequency(cur_mel[0].freq_hz);   /* cambio inmediato */
  if (!audio_running) Audio_Start();
  stage_end_ms = now + NoteDurMs(&cur_mel[0], cur_tempo);
}

static void MelodyService(void)
{
  if (!cur_mel || cur_idx >= cur_len) {
    /* Si terminó y hay loop, reinicia automáticamente */
    if (loop_enabled && loop_mel && loop_len > 0) {
      MelodyStart(loop_mel, loop_len, cur_tempo);
    }
    return;
  }

  uint32_t now = HAL_GetTick();
  if (now < stage_end_ms) return;

  if (cur_stage == 0) {
    /* gap */
    Audio_SetFrequency(0.0f);
    uint32_t dur = NoteDurMs(&cur_mel[cur_idx], cur_tempo) / GAP_DIVISOR;
    if (dur == 0) dur = 1;
    stage_end_ms = now + dur;
    cur_stage = 1;
  } else {
    /* siguiente nota */
    cur_idx++;
    if (cur_idx >= cur_len) {
      /* Terminado: MelodyService() reinicia si loop_enabled */
      Audio_SetFrequency(0.0f);
      return;
    }
    Audio_SetFrequency(cur_mel[cur_idx].freq_hz);
    stage_end_ms = now + NoteDurMs(&cur_mel[cur_idx], cur_tempo);
    cur_stage = 0;
  }
}

/************ SD ************/
static FRESULT SD_Mount(void)    { return f_mount(&g_fs, "", 1); }
static FRESULT SD_Unmount(void)  { return f_mount(NULL, "", 0); }

static FRESULT LoadMelodyFromCSV(const char* path, Note* out_buf, size_t max_notes, unsigned* out_count)
{
  *out_count = 0;
  FRESULT fr = f_open(&g_file, path, FA_READ);
  if (fr != FR_OK) return fr;

  char line[LINE_MAX];
  while (f_gets(line, sizeof(line), &g_file)) {
    char* p = line;
    while (*p==' ' || *p=='\t') ++p;
    if (*p=='#' || *p=='\r' || *p=='\n' || *p=='\0') continue;

    char* sep = strchr(p, ','); if (!sep) sep = strchr(p, ';'); if (!sep) continue;
    *sep = '\0';
    float    freq = strtof(p, NULL);
    unsigned dur  = (unsigned)strtoul(sep+1, NULL, 10);

    if (*out_count < max_notes) {
      out_buf[*out_count].freq_hz   = freq;             /* 0=REST */
      out_buf[*out_count].dur_beats = (uint8_t)(dur & 0xFF);
      (*out_count)++;
    } else break;
  }

  f_close(&g_file);
  return FR_OK;
}

static FRESULT TryOpenList(const char* const* list, size_t n, Note* buf, unsigned* out_cnt)
{
  FRESULT last = FR_NO_FILE; *out_cnt = 0;
  for (size_t i = 0; i < n; ++i) {
    last = LoadMelodyFromCSV(list[i], buf, MELODY_MAX_NOTES, out_cnt);
    log_uart("open path='%s' -> fr=%d, count=%u\r\n", list[i], last, *out_cnt);
    if (last == FR_OK && *out_cnt > 0) return FR_OK;
  }
  return last;
}

/************ Entradas (debounce) ************/
static uint8_t DebounceReadLow(GPIO_TypeDef* port, uint16_t pin, uint32_t ms)
{
  if (HAL_GPIO_ReadPin(port, pin) != GPIO_PIN_RESET) return 0;
  uint32_t t0 = HAL_GetTick();
  while ((HAL_GetTick() - t0) < ms) {
    if (HAL_GPIO_ReadPin(port, pin) != GPIO_PIN_RESET) return 0;
    HAL_Delay(1);
  }
  return 1;
}
static uint8_t DebounceReadHigh(GPIO_TypeDef* port, uint16_t pin, uint32_t ms)
{
  if (HAL_GPIO_ReadPin(port, pin) != GPIO_PIN_SET) return 0;
  uint32_t t0 = HAL_GetTick();
  while ((HAL_GetTick() - t0) < ms) {
    if (HAL_GPIO_ReadPin(port, pin) != GPIO_PIN_SET) return 0;
    HAL_Delay(1);
  }
  return 1;
}

/************ main ************/
int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();            /* PA4 en ANALOG Hi-Z aquí */
  MX_USART2_UART_Init();
  MX_SPI2_Init();
  /* NO llamar MX_DAC_Init() aquí */
  MX_TIM6_Init();
  MX_FATFS_Init();
  MX_DMA_Init();

  /* Config TIM6 a Fs=20kHz, pero NO arrancamos DAC/DMA aún */
  __HAL_TIM_SET_PRESCALER(&htim6, 83);
  __HAL_TIM_SET_AUTORELOAD(&htim6, 49);
  HAL_TIM_GenerateEvent(&htim6, TIM_EVENTSOURCE_UPDATE);

  /* Carga SOLO MELODIA2 (o respaldo) — NO reproducir aún */
  if (SD_Mount() == FR_OK) {
    const char* candidates2[] = {
      "MELODIES/MELODIA2.CSV",
      "/MELODIES/MELODIA2.CSV",
      "0:/MELODIES/MELODIA2.CSV",
      "0:MELODIES/MELODIA2.CSV"
    };
    (void)TryOpenList(candidates2, 4, g_melody2, &g_melody2_count);
    SD_Unmount();
  }
  if (g_melody2_count == 0) {
    log_uart("MELODIA2 CSV no hallada. Usando respaldo embebido.\r\n");
  }
  log_uart("CSV2=%u\r\n", g_melody2_count);

  /* Estado inicial anti-autostart */
  armed = 0;
  started = 0;
  loop_enabled = 0;
  loop_mel = NULL;
  loop_len = 0;

  while (1) {
    /* Anti-autostart: primero HIGH estable, luego LOW estable (flanco H->L) */
    if (!started) {
      if (!armed) {
        if (DebounceReadHigh(TRIG1_GPIO_Port, TRIG1_Pin, DEBOUNCE_MS_HI)) {
          armed = 1;
          log_uart("ARMED (PC2 HIGH estable)\r\n");
        }
      } else {
        if (DebounceReadLow(TRIG1_GPIO_Port, TRIG1_Pin, DEBOUNCE_MS_LO)) {
          const Note* mel = NULL; unsigned cnt = 0;
          if (g_melody2_count) { mel = g_melody2; cnt = g_melody2_count; }
          else                 { mel = IMPERIAL_MARCH; cnt = IMPERIAL_MARCH_LEN; }

          /* === INICIALIZAR DAC JUSTO AQUÍ (única vez) === */
          MX_DAC_Init();  /* crea e inicializa instancia DAC */

          /* Config canal con TRGO de TIM6 */
          DAC_ChannelConfTypeDef s = {0};
          s.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
          s.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
          if (HAL_DAC_ConfigChannel(&hdac, &s, DAC_CHANNEL_1) != HAL_OK) Error_Handler();

          /* Arrancar audio (inicia HAL_DAC_Start + DMA + TIM6) */
          MelodyStart(mel, cnt, CSV_TEMPO_MS);

          /* Loop infinito */
          loop_enabled = 1;
          loop_mel     = mel;
          loop_len     = cnt;

          started = 1;
          log_uart("START LOOP by H->L on PC2 (cnt=%u)\r\n", cnt);
        }
      }
    }

    /* Servicio de reproducción (si terminó y loop_enabled=1, reinicia) */
    MelodyService();

    /* Log de diagnóstico cada ~500 ms */
    static uint32_t t_dbg = 0;
    if (HAL_GetTick() - t_dbg >= 500) {
      t_dbg = HAL_GetTick();
      GPIO_PinState s2 = HAL_GPIO_ReadPin(TRIG1_GPIO_Port, TRIG1_Pin);
      log_uart("PC2=%d ARMED=%u STARTED=%u idx=%u/%u loop=%u\r\n",
               (int)s2, (unsigned)armed, (unsigned)started,
               (unsigned)cur_idx, (unsigned)cur_len, (unsigned)loop_enabled);
    }

    HAL_Delay(POLL_MS);
  }
}

/* ==== Resto CubeMX (definiciones) ==== */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

static void MX_DAC_Init(void)
{
  DAC_ChannelConfTypeDef sConfig = {0};
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK) { Error_Handler(); }
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;            /* se reconfigura luego a TIM6 TRGO */
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM6_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  htim6.Instance = TIM6;
  htim6.Init.Prescaler         = 840-1;
  htim6.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim6.Init.Period            = 9987-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = 16;
  if (HAL_UART_Init(&huart2) != HAL_OK) { Error_Handler(); }
}

static void MX_SPI2_Init(void)
{
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* LED y SD CS */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET); /* CS HIGH */

  /* B1 */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /* LD2 */
  GPIO_InitStruct.Pin   = LD2_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* SD CS */
  GPIO_InitStruct.Pin   = SD_CS_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /* === PA4 en ANALOG Hi-Z para silencio total al boot === */
  GPIO_InitStruct.Pin  = GPIO_PIN_4;           /* PA4 */
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* === PC2 INPUT SIN pull interno (usas pull-up externo) === */
  GPIO_InitStruct.Pin  = TRIG1_Pin;            /* PC2 */
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;          /* SIN pull interno */
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* PC3/PC4 no se usan en esta versión */
}

static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  hdma_dac1.Instance                 = DMA1_Stream5;
  hdma_dac1.Init.Channel             = DMA_CHANNEL_7;
  hdma_dac1.Init.Direction           = DMA_MEMORY_TO_PERIPH;
  hdma_dac1.Init.PeriphInc           = DMA_PINC_DISABLE;
  hdma_dac1.Init.MemInc              = DMA_MINC_ENABLE;
  hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
  hdma_dac1.Init.MemDataAlignment    = DMA_MDATAALIGN_HALFWORD;
  hdma_dac1.Init.Mode                = DMA_CIRCULAR;
  hdma_dac1.Init.Priority            = DMA_PRIORITY_HIGH;
  hdma_dac1.Init.FIFOMode            = DMA_FIFOMODE_DISABLE;
  if (HAL_DMA_Init(&hdma_dac1) != HAL_OK) { Error_Handler(); }

  __HAL_LINKDMA(&hdac, DMA_Handle1, hdma_dac1);

  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
}

/* Callbacks de DAC (DMA circular) */
void HAL_DAC_ConvHalfCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx; FillHalf(0, AUDIO_BUF_SAMPLES/2);
}
void HAL_DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef* hdacx) {
  (void)hdacx; FillHalf(AUDIO_BUF_SAMPLES/2, AUDIO_BUF_SAMPLES/2);
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}
